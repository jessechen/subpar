import{a as t}from"../chunks/entry.ZZv_hoaT.js";export{t as start};
