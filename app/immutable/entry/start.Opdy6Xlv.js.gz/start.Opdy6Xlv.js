import{a as t}from"../chunks/entry.CcFpL9FM.js";export{t as start};
