import{a as t}from"../chunks/entry.DNC6v-5L.js";export{t as start};
