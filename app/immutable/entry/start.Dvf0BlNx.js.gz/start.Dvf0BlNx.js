import{a as t}from"../chunks/entry.D82kvPr3.js";export{t as start};
