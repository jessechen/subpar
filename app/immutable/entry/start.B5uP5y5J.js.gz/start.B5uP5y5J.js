import{a as t}from"../chunks/entry.R_pyOqIg.js";export{t as start};
